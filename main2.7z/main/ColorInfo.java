package main;

import java.awt.Color;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 10505053950
 */
public class ColorInfo {
    public Color color;
    public int index;
    
    public ColorInfo (Color color, int index) {
        this.color = color;
        this.index = index;
    }
}
