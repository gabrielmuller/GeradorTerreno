package main;

import java.awt.*;

import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author 10505053950
 */
public class Interface extends JPanel {

    JCheckBox changeColorCheckbox;
    JColorChooser colorChooser;
    JSlider seaLevelSlider;
    JButton updateButton;
    JTextField seedInput;
    int sliderSize = 100;

    public Interface() {
        super(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        colorChooser = new JColorChooser();
        changeColorCheckbox = new JCheckBox();
        seaLevelSlider = new JSlider(-sliderSize, sliderSize, 0);
        updateButton = new JButton();
        seedInput = new JTextField();

        updateButton.setText("Update");
        seedInput.setText("seed");
        changeColorCheckbox.setSelected(false);
        changeColorCheckbox.setText("Change colors");
        updateButton.setPreferredSize(new Dimension(50, 50));
        //add(colorChooser, BorderLayout.PAGE_END);
        //add(changeColorCheckbox, BorderLayout.PAGE_START);
        c.gridy = 0;
        c.gridx = 0;
        add(changeColorCheckbox, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridy = 1;
        add(updateButton, c);

        c.gridy = 2;
        add(seaLevelSlider, c);

        c.gridy = 3;

        add(seedInput, c);

        c.gridy = 4;
        add(colorChooser, c);

    }

    public boolean isChangingColor() {
        return changeColorCheckbox.isSelected();
    }

    public Color getSelectedColor() {
        return colorChooser.getColor();
    }

    public float getSeaLevel() {
        return seaLevelSlider.getValue() / (float) sliderSize;
    }

    public long getSeed() {
        String input = seedInput.getText();
        input = input.replaceAll("\\s+", "");
        if (input.length() > 8) {
            input = input.substring(0, 8);
        }
        return Long.parseLong(input, 36);
    }
}
